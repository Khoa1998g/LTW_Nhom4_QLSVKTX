﻿namespace lab02_02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblThongTin = new System.Windows.Forms.Label();
            this.lblTile = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSex = new System.Windows.Forms.Label();
            this.lblAvScore = new System.Windows.Forms.Label();
            this.lblFaculty = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.rbNam = new System.Windows.Forms.RadioButton();
            this.rbNu = new System.Windows.Forms.RadioButton();
            this.txtAvScore = new System.Windows.Forms.TextBox();
            this.cbFaculty = new System.Windows.Forms.ComboBox();
            this.btnThemSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dgvStudent = new System.Windows.Forms.DataGridView();
            this.clID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAvScore = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clFaculty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTongNam = new System.Windows.Forms.Label();
            this.lblTongNu = new System.Windows.Forms.Label();
            this.txtTongNam = new System.Windows.Forms.TextBox();
            this.txtTongNu = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // lblThongTin
            // 
            this.lblThongTin.AutoSize = true;
            this.lblThongTin.Location = new System.Drawing.Point(10, 144);
            this.lblThongTin.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblThongTin.Name = "lblThongTin";
            this.lblThongTin.Size = new System.Drawing.Size(194, 25);
            this.lblThongTin.TabIndex = 0;
            this.lblThongTin.Text = "Thông tin sinh viên";
            // 
            // lblTile
            // 
            this.lblTile.AutoSize = true;
            this.lblTile.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblTile.Location = new System.Drawing.Point(248, 65);
            this.lblTile.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTile.Name = "lblTile";
            this.lblTile.Size = new System.Drawing.Size(542, 46);
            this.lblTile.TabIndex = 1;
            this.lblTile.Text = "Quản Lý Thông Tin Sinh Viên";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(64, 219);
            this.lblID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(140, 25);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Mã Sinh Viên";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(64, 277);
            this.lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(82, 25);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Họ Tên";
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Location = new System.Drawing.Point(64, 335);
            this.lblSex.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(98, 25);
            this.lblSex.TabIndex = 0;
            this.lblSex.Text = "Giới Tính";
            // 
            // lblAvScore
            // 
            this.lblAvScore.AutoSize = true;
            this.lblAvScore.Location = new System.Drawing.Point(64, 392);
            this.lblAvScore.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAvScore.Name = "lblAvScore";
            this.lblAvScore.Size = new System.Drawing.Size(94, 25);
            this.lblAvScore.TabIndex = 0;
            this.lblAvScore.Text = "Điểm TB";
            // 
            // lblFaculty
            // 
            this.lblFaculty.AutoSize = true;
            this.lblFaculty.Location = new System.Drawing.Point(64, 450);
            this.lblFaculty.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFaculty.Name = "lblFaculty";
            this.lblFaculty.Size = new System.Drawing.Size(155, 25);
            this.lblFaculty.TabIndex = 0;
            this.lblFaculty.Text = "Chuyên Ngành";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(258, 206);
            this.txtID.Margin = new System.Windows.Forms.Padding(6);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(330, 31);
            this.txtID.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(258, 263);
            this.txtName.Margin = new System.Windows.Forms.Padding(6);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(330, 31);
            this.txtName.TabIndex = 1;
            // 
            // rbNam
            // 
            this.rbNam.AutoSize = true;
            this.rbNam.Location = new System.Drawing.Point(258, 315);
            this.rbNam.Margin = new System.Windows.Forms.Padding(6);
            this.rbNam.Name = "rbNam";
            this.rbNam.Size = new System.Drawing.Size(87, 29);
            this.rbNam.TabIndex = 2;
            this.rbNam.TabStop = true;
            this.rbNam.Text = "Nam";
            this.rbNam.UseVisualStyleBackColor = true;
            // 
            // rbNu
            // 
            this.rbNu.AutoSize = true;
            this.rbNu.Location = new System.Drawing.Point(364, 315);
            this.rbNu.Margin = new System.Windows.Forms.Padding(6);
            this.rbNu.Name = "rbNu";
            this.rbNu.Size = new System.Drawing.Size(70, 29);
            this.rbNu.TabIndex = 3;
            this.rbNu.TabStop = true;
            this.rbNu.Text = "Nữ";
            this.rbNu.UseVisualStyleBackColor = true;
            // 
            // txtAvScore
            // 
            this.txtAvScore.Location = new System.Drawing.Point(258, 379);
            this.txtAvScore.Margin = new System.Windows.Forms.Padding(6);
            this.txtAvScore.Name = "txtAvScore";
            this.txtAvScore.Size = new System.Drawing.Size(238, 31);
            this.txtAvScore.TabIndex = 4;
            // 
            // cbFaculty
            // 
            this.cbFaculty.FormattingEnabled = true;
            this.cbFaculty.Items.AddRange(new object[] {
            "QTKD",
            "CNTT",
            "NNA"});
            this.cbFaculty.Location = new System.Drawing.Point(258, 433);
            this.cbFaculty.Margin = new System.Windows.Forms.Padding(6);
            this.cbFaculty.Name = "cbFaculty";
            this.cbFaculty.Size = new System.Drawing.Size(238, 33);
            this.cbFaculty.TabIndex = 5;
            // 
            // btnThemSua
            // 
            this.btnThemSua.Location = new System.Drawing.Point(258, 519);
            this.btnThemSua.Margin = new System.Windows.Forms.Padding(6);
            this.btnThemSua.Name = "btnThemSua";
            this.btnThemSua.Size = new System.Drawing.Size(150, 44);
            this.btnThemSua.TabIndex = 6;
            this.btnThemSua.Text = "Thêm/Sửa";
            this.btnThemSua.UseVisualStyleBackColor = true;
            this.btnThemSua.Click += new System.EventHandler(this.btnThemSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(442, 519);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(150, 44);
            this.btnXoa.TabIndex = 7;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // dgvStudent
            // 
            this.dgvStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clID,
            this.clName,
            this.clSex,
            this.clAvScore,
            this.clFaculty});
            this.dgvStudent.Location = new System.Drawing.Point(619, 144);
            this.dgvStudent.Margin = new System.Windows.Forms.Padding(6);
            this.dgvStudent.Name = "dgvStudent";
            this.dgvStudent.RowHeadersWidth = 82;
            this.dgvStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStudent.Size = new System.Drawing.Size(893, 419);
            this.dgvStudent.TabIndex = 8;
            this.dgvStudent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStudent_CellClick);
            // 
            // clID
            // 
            this.clID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.clID.HeaderText = "MSSV";
            this.clID.MinimumWidth = 10;
            this.clID.Name = "clID";
            this.clID.Width = 117;
            // 
            // clName
            // 
            this.clName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clName.HeaderText = "Họ Tên";
            this.clName.MinimumWidth = 10;
            this.clName.Name = "clName";
            this.clName.Width = 118;
            // 
            // clSex
            // 
            this.clSex.HeaderText = "Giới tính";
            this.clSex.MinimumWidth = 10;
            this.clSex.Name = "clSex";
            this.clSex.Width = 72;
            // 
            // clAvScore
            // 
            this.clAvScore.HeaderText = "ĐTB";
            this.clAvScore.MinimumWidth = 10;
            this.clAvScore.Name = "clAvScore";
            this.clAvScore.Width = 54;
            // 
            // clFaculty
            // 
            this.clFaculty.HeaderText = "Khoa";
            this.clFaculty.MinimumWidth = 10;
            this.clFaculty.Name = "clFaculty";
            this.clFaculty.Width = 200;
            // 
            // lblTongNam
            // 
            this.lblTongNam.AutoSize = true;
            this.lblTongNam.Location = new System.Drawing.Point(1022, 606);
            this.lblTongNam.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTongNam.Name = "lblTongNam";
            this.lblTongNam.Size = new System.Drawing.Size(145, 25);
            this.lblTongNam.TabIndex = 9;
            this.lblTongNam.Text = "Tổng SV Nam";
            // 
            // lblTongNu
            // 
            this.lblTongNu.AutoSize = true;
            this.lblTongNu.Location = new System.Drawing.Point(1286, 606);
            this.lblTongNu.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTongNu.Name = "lblTongNu";
            this.lblTongNu.Size = new System.Drawing.Size(39, 25);
            this.lblTongNu.TabIndex = 10;
            this.lblTongNu.Text = "Nữ";
            // 
            // txtTongNam
            // 
            this.txtTongNam.Location = new System.Drawing.Point(1182, 592);
            this.txtTongNam.Margin = new System.Windows.Forms.Padding(6);
            this.txtTongNam.Name = "txtTongNam";
            this.txtTongNam.ReadOnly = true;
            this.txtTongNam.Size = new System.Drawing.Size(90, 31);
            this.txtTongNam.TabIndex = 11;
            // 
            // txtTongNu
            // 
            this.txtTongNu.Location = new System.Drawing.Point(1340, 592);
            this.txtTongNu.Margin = new System.Windows.Forms.Padding(6);
            this.txtTongNu.Name = "txtTongNu";
            this.txtTongNu.ReadOnly = true;
            this.txtTongNu.Size = new System.Drawing.Size(90, 31);
            this.txtTongNu.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1573, 720);
            this.Controls.Add(this.txtTongNu);
            this.Controls.Add(this.txtTongNam);
            this.Controls.Add(this.lblTongNu);
            this.Controls.Add(this.lblTongNam);
            this.Controls.Add(this.dgvStudent);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnThemSua);
            this.Controls.Add(this.cbFaculty);
            this.Controls.Add(this.txtAvScore);
            this.Controls.Add(this.rbNu);
            this.Controls.Add(this.rbNam);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.lblTile);
            this.Controls.Add(this.lblFaculty);
            this.Controls.Add(this.lblAvScore);
            this.Controls.Add(this.lblSex);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblThongTin);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblThongTin;
        private System.Windows.Forms.Label lblTile;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.Label lblAvScore;
        private System.Windows.Forms.Label lblFaculty;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.RadioButton rbNam;
        private System.Windows.Forms.RadioButton rbNu;
        private System.Windows.Forms.TextBox txtAvScore;
        private System.Windows.Forms.ComboBox cbFaculty;
        private System.Windows.Forms.Button btnThemSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.DataGridView dgvStudent;
        private System.Windows.Forms.Label lblTongNam;
        private System.Windows.Forms.Label lblTongNu;
        private System.Windows.Forms.TextBox txtTongNam;
        private System.Windows.Forms.TextBox txtTongNu;
        private System.Windows.Forms.DataGridViewTextBoxColumn clID;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAvScore;
        private System.Windows.Forms.DataGridViewTextBoxColumn clFaculty;
    }
}


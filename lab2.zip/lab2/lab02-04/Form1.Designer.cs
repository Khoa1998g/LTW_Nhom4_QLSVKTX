﻿namespace lab02_04
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTile = new System.Windows.Forms.Label();
            this.lblSoTaiKhoan = new System.Windows.Forms.Label();
            this.txtSoTaiKhoan = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblSoTien = new System.Windows.Forms.Label();
            this.txtSoTien = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.lvThongTinTaiKhoan = new System.Windows.Forms.ListView();
            this.clSTT = new System.Windows.Forms.ColumnHeader();
            this.clSoTaiKhoan = new System.Windows.Forms.ColumnHeader();
            this.clName = new System.Windows.Forms.ColumnHeader();
            this.clDiaChi = new System.Windows.Forms.ColumnHeader();
            this.clSoTien = new System.Windows.Forms.ColumnHeader();
            this.btnSua = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTile
            // 
            this.lblTile.AutoSize = true;
            this.lblTile.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTile.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblTile.Location = new System.Drawing.Point(140, 0);
            this.lblTile.Name = "lblTile";
            this.lblTile.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTile.Size = new System.Drawing.Size(1011, 106);
            this.lblTile.TabIndex = 0;
            this.lblTile.Text = "Quản lý thông tin tài khoản";
            this.lblTile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSoTaiKhoan
            // 
            this.lblSoTaiKhoan.AutoSize = true;
            this.lblSoTaiKhoan.Location = new System.Drawing.Point(125, 130);
            this.lblSoTaiKhoan.Name = "lblSoTaiKhoan";
            this.lblSoTaiKhoan.Size = new System.Drawing.Size(147, 32);
            this.lblSoTaiKhoan.TabIndex = 1;
            this.lblSoTaiKhoan.Text = "Số tài khoản";
            // 
            // txtSoTaiKhoan
            // 
            this.txtSoTaiKhoan.Location = new System.Drawing.Point(289, 130);
            this.txtSoTaiKhoan.Name = "txtSoTaiKhoan";
            this.txtSoTaiKhoan.Size = new System.Drawing.Size(852, 39);
            this.txtSoTaiKhoan.TabIndex = 0;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(89, 189);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(183, 32);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Tên khách hàng";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(289, 189);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(852, 39);
            this.txtName.TabIndex = 1;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(54, 239);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(218, 32);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa chỉ khách hàng";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(289, 239);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(852, 39);
            this.txtDiaChi.TabIndex = 2;
            // 
            // lblSoTien
            // 
            this.lblSoTien.AutoSize = true;
            this.lblSoTien.Location = new System.Drawing.Point(12, 295);
            this.lblSoTien.Name = "lblSoTien";
            this.lblSoTien.Size = new System.Drawing.Size(260, 32);
            this.lblSoTien.TabIndex = 1;
            this.lblSoTien.Text = "Số tiền trong tài khoản";
            // 
            // txtSoTien
            // 
            this.txtSoTien.Location = new System.Drawing.Point(289, 295);
            this.txtSoTien.Name = "txtSoTien";
            this.txtSoTien.Size = new System.Drawing.Size(852, 39);
            this.txtSoTien.TabIndex = 3;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Location = new System.Drawing.Point(578, 350);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(150, 46);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Location = new System.Drawing.Point(757, 350);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(150, 46);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Xoá";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExit
            // 
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Location = new System.Drawing.Point(1114, 350);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 46);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Thoát";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Location = new System.Drawing.Point(790, 778);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(117, 32);
            this.lblTongTien.TabIndex = 7;
            this.lblTongTien.Text = "Tổng tiền";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(936, 771);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.Size = new System.Drawing.Size(187, 39);
            this.txtTongTien.TabIndex = 8;
            // 
            // lvThongTinTaiKhoan
            // 
            this.lvThongTinTaiKhoan.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clSTT,
            this.clSoTaiKhoan,
            this.clName,
            this.clDiaChi,
            this.clSoTien});
            this.lvThongTinTaiKhoan.FullRowSelect = true;
            this.lvThongTinTaiKhoan.GridLines = true;
            this.lvThongTinTaiKhoan.Location = new System.Drawing.Point(54, 402);
            this.lvThongTinTaiKhoan.Name = "lvThongTinTaiKhoan";
            this.lvThongTinTaiKhoan.Size = new System.Drawing.Size(1175, 365);
            this.lvThongTinTaiKhoan.TabIndex = 9;
            this.lvThongTinTaiKhoan.UseCompatibleStateImageBehavior = false;
            this.lvThongTinTaiKhoan.View = System.Windows.Forms.View.Details;
            this.lvThongTinTaiKhoan.SelectedIndexChanged += new System.EventHandler(this.lvThongTinTaiKhoan_SelectedIndexChanged);
            // 
            // clSTT
            // 
            this.clSTT.Text = "STT";
            // 
            // clSoTaiKhoan
            // 
            this.clSoTaiKhoan.Text = "Mã tài khoản";
            // 
            // clName
            // 
            this.clName.Text = "Tên khách hàng";
            // 
            // clDiaChi
            // 
            this.clDiaChi.Text = "Địa chỉ khách hàng";
            // 
            // clSoTien
            // 
            this.clSoTien.Text = "Số tiền trong tài khoản";
            // 
            // btnSua
            // 
            this.btnSua.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSua.Location = new System.Drawing.Point(936, 350);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(150, 46);
            this.btnSua.TabIndex = 6;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1287, 822);
            this.Controls.Add(this.lvThongTinTaiKhoan);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtSoTien);
            this.Controls.Add(this.lblSoTien);
            this.Controls.Add(this.txtDiaChi);
            this.Controls.Add(this.lblDiaChi);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.txtSoTaiKhoan);
            this.Controls.Add(this.lblSoTaiKhoan);
            this.Controls.Add(this.lblTile);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTile;
        private Label lblSoTaiKhoan;
        private TextBox txtSoTaiKhoan;
        private Label lblName;
        private TextBox txtName;
        private Label lblDiaChi;
        private TextBox txtDiaChi;
        private Label lblSoTien;
        private TextBox txtSoTien;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnExit;
        private Label lblTongTien;
        private TextBox txtTongTien;
        private ListView lvThongTinTaiKhoan;
        private ColumnHeader clSTT;
        private ColumnHeader clSoTaiKhoan;
        private ColumnHeader clName;
        private ColumnHeader clDiaChi;
        private ColumnHeader clSoTien;
        private Button btnSua;
    }
}
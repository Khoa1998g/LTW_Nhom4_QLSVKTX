﻿namespace lab02_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lvThongTinTaiKhoan.Columns[0].Width = (int)(lvThongTinTaiKhoan.Width * 0.05);
            lvThongTinTaiKhoan.Columns[1].Width = (int)(lvThongTinTaiKhoan.Width * 0.15);
            lvThongTinTaiKhoan.Columns[2].Width = (int)(lvThongTinTaiKhoan.Width * 0.25);
            lvThongTinTaiKhoan.Columns[3].Width = (int)(lvThongTinTaiKhoan.Width * 0.25);
            lvThongTinTaiKhoan.Columns[4].Width = (int)(lvThongTinTaiKhoan.Width * 0.3);
            lvThongTinTaiKhoan.View = View.Details;
            txtTongTien.Text = "0";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            ListViewItem item = lvThongTinTaiKhoan.Items.Add((lvThongTinTaiKhoan.Items.Count + 1).ToString());
            item.SubItems.Add(txtSoTaiKhoan.Text);
            item.SubItems.Add(txtName.Text);
            item.SubItems.Add(txtDiaChi.Text);
            item.SubItems.Add(int.Parse(txtSoTien.Text).ToString());
            txtSoTaiKhoan.Text = "";
            txtName.Text = "";
            txtDiaChi.Text = "";
            txtSoTien.Text = "";
            txtTongTien.Text = tongTien().ToString();
            MessageBox.Show("Thêm thông tin thành công!");
        }                   
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lvThongTinTaiKhoan.SelectedItems.Count > 0)
            {
                lvThongTinTaiKhoan.Items.Remove(lvThongTinTaiKhoan.SelectedItems[0]);
                txtTongTien.Text = tongTien().ToString();
                MessageBox.Show("Xoá thông tin thành công!");
            }
            else
            {
                MessageBox.Show("Phải chọn ít nhất 1 dòng!");
            }
        }

        private void lvThongTinTaiKhoan_SelectedIndexChanged(object sender, EventArgs e)
        {            if (lvThongTinTaiKhoan.SelectedItems.Count > 0)
            {
                txtSoTaiKhoan.Text = lvThongTinTaiKhoan.SelectedItems[0].SubItems[1].Text;
                txtName.Text = lvThongTinTaiKhoan.SelectedItems[0].SubItems[2].Text;
                txtDiaChi.Text = lvThongTinTaiKhoan.SelectedItems[0].SubItems[3].Text;
                txtSoTien.Text = lvThongTinTaiKhoan.SelectedItems[0].SubItems[4].Text;
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (lvThongTinTaiKhoan.SelectedItems.Count > 0)
            {
                lvThongTinTaiKhoan.SelectedItems[0].SubItems[1].Text = txtSoTaiKhoan.Text;
                lvThongTinTaiKhoan.SelectedItems[0].SubItems[2].Text = txtName.Text;
                lvThongTinTaiKhoan.SelectedItems[0].SubItems[3].Text = txtDiaChi.Text;
                lvThongTinTaiKhoan.SelectedItems[0].SubItems[4].Text = txtSoTien.Text;
                txtTongTien.Text = tongTien().ToString();
                MessageBox.Show("Sửa thông tin thành công!");
            }
        }
        private int tongTien()
        {
            int tongTien = 0;
            for (int i = 0; i < lvThongTinTaiKhoan.Items.Count; i++)
            {
                tongTien += int.Parse(lvThongTinTaiKhoan.Items[i].SubItems[4].Text);
            }
           
            return tongTien;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab02_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbFaculty.SelectedIndex = 0;
            txtTongNam.Text = "0";
            txtTongNu.Text = "0";
            
        }
        private int getSelectedRow(string studentID)
        {

            for(int i=0; i< dgvStudent.Rows.Count; i++)
            {
                if (dgvStudent.Rows[0].Cells[0].Value == null)
                {
                    dgvStudent.Rows[0].Cells[0].Value = studentID;
                }
                if (dgvStudent.Rows[i].Cells[0].Value.ToString() == studentID)
                {
                    return i;
                }
            }
            return -1;
        }
        private void InsertUpdate(int selectedRow)
        {
            dgvStudent.Rows[selectedRow].Cells[0].Value = txtID.Text;
            dgvStudent.Rows[selectedRow].Cells[1].Value = txtName.Text;
            dgvStudent.Rows[selectedRow].Cells[2].Value = rbNu.Checked? "Nữ":"Nam";
            dgvStudent.Rows[selectedRow].Cells[3].Value = float.Parse(txtAvScore.Text).ToString() ;
            dgvStudent.Rows[selectedRow].Cells[4].Value = cbFaculty.Text;
        }
        private int tongNam()
        {
            int count = dgvStudent.Rows.Count;
            int tong = 0;
            for (int i = 0; i < count; i++)
            {
                if (dgvStudent.Rows[i].Cells[2].Value.ToString() == "Nam")
                    tong +=1;
            }
            return tong;
        }
        private int tongNu()
        {
            int count = dgvStudent.Rows.Count;
            int tong = 0;
            for (int i = 0; i < count; i++)
            {
                if (dgvStudent.Rows[i].Cells[2].Value.ToString() == "Nữ")
                    tong += 1;
            }
            return tong;
        }
        private void btnThemSua_Click(object sender, EventArgs e)
        {
            if (dgvStudent.Rows.Count != 0)
            {
                try
                {
                    if (txtID.Text == "" || txtName.Text == "" || txtAvScore.Text == "")
                    {
                        throw new Exception("Vui lòng nhập đầy đủ thông tin sinh viên");
                    }
                    int selectedRow = getSelectedRow(txtID.Text);
                    if (selectedRow == -1)
                    {
                        selectedRow = dgvStudent.Rows.Add();
                        InsertUpdate(selectedRow);
                        MessageBox.Show("Thêm mới dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK);
                        txtTongNam.Text = tongNam().ToString();
                        txtTongNu.Text = tongNu().ToString();
                    }
                    else
                    {
                        InsertUpdate(selectedRow);
                        MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {

                int selectedRow = getSelectedRow(txtID.Text);
                if (selectedRow == -1)
                {
                    throw new Exception("Không tìm thấy MSSV cần xóa");
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Bạn có muốn xóa ?", "YES/NO", MessageBoxButtons.YesNo);
                    if(dr == DialogResult.Yes)
                    {
                        dgvStudent.Rows.RemoveAt(selectedRow);
                        MessageBox.Show("Xóa sinh viên thành công!", "Thông Báo", MessageBoxButtons.OK);
                        txtTongNam.Text = tongNam().ToString();
                        txtTongNu.Text = tongNu().ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvStudent.SelectedCells.Count > 0)
            {
                try
                {
                    if (dgvStudent.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    {
                        txtID.Text = dgvStudent.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
                        txtName.Text = dgvStudent.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
                        txtAvScore.Text = dgvStudent.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
                        if (dgvStudent.Rows[e.RowIndex].Cells[2].Value.ToString() == "Nữ")
                        {
                            rbNu.Checked = true;
                        }
                        else
                        {
                            rbNam.Checked = true;
                        }
                        cbFaculty.SelectedItem = dgvStudent.Rows[e.RowIndex].Cells[4].FormattedValue.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
               
                
        }
    }
}

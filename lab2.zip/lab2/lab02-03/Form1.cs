﻿namespace lab02_03
{
    public partial class Form1 : Form
    {
        List <Button> danhSachChon = new List <Button> ();
        int thanhTien = 0;
        private string phepToan;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gr1.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add (btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove (btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn.BackColor == Color.White)
            {
                btn.BackColor = Color.Blue;
                danhSachChon.Add(btn);
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.White;
                danhSachChon.Remove(btn);
            }
            else if (btn.BackColor == Color.Yellow)
            {
                MessageBox.Show("Ghế đã được bán!");
            }
        }

        private void btnChon_Click(object sender, EventArgs e)
        {
            foreach(Button btn in danhSachChon)
            {
                int a = int.Parse(btn.Text);
                if(a <= 5)
                {
                    btn.BackColor = Color.Yellow;
                    thanhTien += 5000;
                }
                if ( a> 5 && a<=10)
                {
                    btn.BackColor = Color.Yellow;
                    thanhTien += 6500;
                }
                if (a > 10 && a <= 15)
                {
                    btn.BackColor = Color.Yellow;
                    thanhTien += 8000;
                }
            }
            txtThanhTien.Text = thanhTien.ToString();
            thanhTien = 0;
            danhSachChon = new List<Button>();
        }

        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            foreach(Button btn in danhSachChon)
            {
                base.BackColor = Color.White;
            }
            txtThanhTien.Text = "";
            danhSachChon = new List<Button>();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát không ?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if(r == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }

}